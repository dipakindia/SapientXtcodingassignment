import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NewsService {
  public api_url = 'https://hn.algolia.com/api/v1/search?query=news';
  
  constructor(private http: HttpClient) { }

  getAllData(page){
    return this.http.get(this.api_url+'&page='+page);
  }

}
