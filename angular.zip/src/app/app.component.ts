import { Component } from '@angular/core';
import { NewsService } from './news.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'xtcodingassignment';
  public newsList:any = [];
  public page = 0;
  constructor(private news: NewsService){
    this.loadData(this.page);
  }

  loadData(page){
    this.news.getAllData(page).subscribe(data => {
      this.newsList = data['hits'];
    });
  }
  next(){
    this.page = this.page + 1;
    this.loadData(this.page);
  }
  prev(){
    this.page = this.page - 1;
    this.loadData(this.page);
  }
}
